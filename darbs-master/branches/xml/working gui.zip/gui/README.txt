This file is for you to describe the gui application. Typically
you would include information such as the information below:

Installation and Setup
======================

Install ``gui`` using easy_install::

    easy_install gui

Make a config file as follows::

    paster make-config gui config.ini

Tweak the config file as appropriate and then setup the application::

    paster setup-app config.ini

Then you are ready to go.
